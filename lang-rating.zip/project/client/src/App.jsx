import { useState, useEffect } from "react";

const API = "http://localhost:3001/api/votes";

const LANGUAGES = ["JavaScript", "Python", "C++"];

function langClass(name) {
  if (name === "JavaScript") return "js";
  if (name === "Python") return "py";
  return "cpp";
}

export default function App() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [serverError, setServerError] = useState(false);

  const [selected, setSelected] = useState("");
  const [voter, setVoter] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [feedback, setFeedback] = useState(null);

  const fetchData = async () => {
    try {
      const res = await fetch(API);
      const json = await res.json();
      setData(json);
      setServerError(false);
    } catch {
      setServerError(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSubmit = async () => {
    if (!selected) {
      setFeedback({ type: "error", text: "Оберіть мову перед голосуванням." });
      return;
    }

    setSubmitting(true);
    setFeedback(null);

    try {
      const res = await fetch(API, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ language: selected, voter: voter.trim() }),
      });

      const json = await res.json();

      if (!res.ok) {
        const msg = json.errors ? json.errors.join(" ") : "Помилка сервера.";
        setFeedback({ type: "error", text: msg });
        return;
      }

      setData({
        total: json.total,
        languages: json.languages,
        log: [...(data?.log ?? []), json.entry],
      });

      setFeedback({ type: "success", text: json.message });
      setSelected("");
      setVoter("");
    } catch {
      setFeedback({ type: "error", text: "Неможливо з'єднатися з сервером." });
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return <div className="app"><p className="status">Завантаження...</p></div>;
  }

  if (serverError) {
    return (
      <div className="app">
        <div className="server-error">
          <p className="error-title">Сервер недоступний</p>
          <p className="error-hint">Запустіть: cd server &amp;&amp; node index.js</p>
          <button className="submit-btn" onClick={fetchData}>Спробувати знову</button>
        </div>
      </div>
    );
  }

  const languages = data?.languages ?? [];
  const log = data?.log ?? [];
  const total = data?.total ?? 0;

  return (
    <div className="app">
      <header className="header">
        <h1>Рейтинг мов програмування</h1>
        <p>Проголосуйте за свою улюблену мову</p>
      </header>

      <div className="card">
        <p className="card-title">Голосування</p>
        <div className="lang-buttons">
          {LANGUAGES.map((lang) => (
            <button
              key={lang}
              className={"lang-btn " + langClass(lang) + (selected === lang ? " selected" : "")}
              onClick={() => setSelected(lang)}
            >
              {lang}
            </button>
          ))}
        </div>
        <input
          className="voter-input"
          type="text"
          placeholder="Ваше ім'я (необов'язково)"
          value={voter}
          onChange={(e) => setVoter(e.target.value)}
        />
        <button className="submit-btn" onClick={handleSubmit} disabled={submitting}>
          {submitting ? "Відправка..." : "Проголосувати"}
        </button>
        {feedback && <p className={"msg " + feedback.type}>{feedback.text}</p>}
      </div>

      <div className="card">
        <p className="card-title">Результати</p>
        {languages.map((l) => (
          <div className="bar-row" key={l.language}>
            <span className="bar-label">{l.language}</span>
            <div className="bar-track">
              <div className={"bar-fill " + langClass(l.language)} style={{ width: l.percent + "%" }} />
            </div>
            <span className="bar-pct">{l.percent}%</span>
            <span className="bar-count">{l.votes} гол.</span>
          </div>
        ))}
        <p className="total">Всього голосів: {total}</p>
      </div>

      <div className="card">
        <p className="card-title">Журнал голосів</p>
        {log.length === 0 ? (
          <p className="empty">Голосів ще немає.</p>
        ) : (
          <table className="log-table">
            <thead>
              <tr><th>#</th><th>Мова</th><th>Учасник</th><th>Час</th></tr>
            </thead>
            <tbody>
              {[...log].reverse().map((entry) => (
                <tr key={entry.id}>
                  <td className="muted">{entry.id}</td>
                  <td><span className={"tag " + langClass(entry.language)}>{entry.language}</span></td>
                  <td>{entry.voter}</td>
                  <td className="muted">{new Date(entry.time).toLocaleTimeString("uk-UA")}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
