import express from "express";
import cors from "cors";

const app = express();
const PORT = 3001;

app.use(express.json());
app.use(cors({ origin: "http://localhost:5173" }));

// Допустимі мови
const LANGUAGES = ["JavaScript", "Python", "C++"];

// Збережені дані (in-memory)
const votes = { JavaScript: 0, Python: 0, "C++": 0 };
const log = [];

// Валідація тіла запиту
function validate(body) {
  const errors = [];

  if (!body.language) {
    errors.push("Поле 'language' є обов'язковим.");
    return errors;
  }

  if (typeof body.language !== "string") {
    errors.push("Поле 'language' має бути рядком.");
    return errors;
  }

  if (body.language.trim().length < 2) {
    errors.push("Поле 'language' має містити мінімум 2 символи.");
  }

  if (!LANGUAGES.includes(body.language.trim())) {
    errors.push(`Дозволені значення: ${LANGUAGES.join(", ")}.`);
  }

  if (body.voter !== undefined) {
    if (typeof body.voter !== "string") {
      errors.push("Поле 'voter' має бути рядком.");
    } else if (body.voter.trim().length === 1) {
      errors.push("Поле 'voter' має містити мінімум 2 символи або бути порожнім.");
    }
  }

  return errors;
}

// GET /api/votes
app.get("/api/votes", (req, res) => {
  const total = Object.values(votes).reduce((sum, v) => sum + v, 0);

  const languages = LANGUAGES.map((lang) => ({
    language: lang,
    votes: votes[lang],
    percent: total === 0 ? 0 : Math.round((votes[lang] / total) * 100),
  }));

  res.json({ total, languages, log });
});

// POST /api/votes
app.post("/api/votes", (req, res) => {
  const errors = validate(req.body);

  if (errors.length > 0) {
    return res.status(400).json({ errors });
  }

  const language = req.body.language.trim();
  const voter = req.body.voter?.trim() || "Анонім";

  votes[language] += 1;

  const entry = {
    id: log.length + 1,
    language,
    voter,
    time: new Date().toISOString(),
  };
  log.push(entry);

  const total = Object.values(votes).reduce((sum, v) => sum + v, 0);
  const languages = LANGUAGES.map((lang) => ({
    language: lang,
    votes: votes[lang],
    percent: total === 0 ? 0 : Math.round((votes[lang] / total) * 100),
  }));

  res.status(201).json({ message: `Голос за ${language} прийнято.`, entry, total, languages });
});

app.listen(PORT, () => {
  console.log("Сервер запущено: http://localhost:" + PORT);
});
